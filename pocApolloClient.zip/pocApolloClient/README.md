
### Create App 
```
npx create-react-app redux-crud-app
```
### Start App
```
npm run start
```

### Install Dom Router

```
npm install react-router-dom --save
npm install react-router-dom@5  (For switch)
```

### Steps
```
1. Create User Folder 
2. Create UserList.jsx for List out User 
3. Add UserList Router  on App.js
4. Change User List Files Content 
```
### Install Redux for load user from store and state

```
 npm install @reduxjs/toolkit react-redux --save
```