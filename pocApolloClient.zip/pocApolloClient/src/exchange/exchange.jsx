import { useSelector } from "react-redux";
import React from "react";
function ExchangeRates() {
  const { currency } = useSelector((state) => {
    return state.user;
  });

  return currency?.length ? (
    currency.map(({ currency, rate }) => (
      <div key={currency}>
        <p>
          {currency}: {rate}
        </p>
      </div>
    ))
  ) : (
    <div>Loading....</div>
  );
}
export default ExchangeRates;
