import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { gql } from "@apollo/client";
import { client } from '../apolloClient';
import axios from 'axios';

export const fetchApolloExchange = createAsyncThunk("fetchApolloCurrency", async () => {
    return client.query({
        fetchPolicy: 'network-only',
        query: gql`
        {
            rates(currency: "USD") {
                currency
                rate
              }
        }`
    })
});

const exchangeSlice = createSlice({
    name: "exchange",
    initialState: {
        loading: false,
        exchange: []
    },
    reducers: {

    },
    extraReducers: {
        [fetchApolloExchange.pending]: (state, action) => {
            state.loading = true;
        },
        [fetchApolloExchange.fulfilled]: (state, action) => {
            state.loading = false;
            state.currency = [...action.payload.data.rates];
        },
        [fetchApolloExchange.rejected]: (state, action) => {
            state.loading = false;
        }
    },

});
export default exchangeSlice.reducer;
