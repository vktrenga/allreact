import { configureStore } from "@reduxjs/toolkit";
import exchangeReducer from "./exchange/exchangeSlice";

export default configureStore({
    reducer: {
        user: exchangeReducer
    },
});