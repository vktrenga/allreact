import { Route, BrowserRouter as Router, Switch } from "react-router-dom";
import React from "react";
import ExchangeRates from './exchange/exchange';

export default function App() {
  return (
    <Router>
      <div>
        <Switch>
          <Route path="/">
            <div className="two columns">
              <ExchangeRates
              />
            </div>
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

